<?php

use Illuminate\Support\Facades\Route;
use Inertia\Inertia;

Route::get('/', function () {
    return Inertia::render('dashboard');
})->name('home');

Route::middleware(['auth'])->group(function () {
    Route::get('dashboard', function () {
        return Inertia::render('dashboard'); 
    })->name('dashboard');
});


Route::get('/sigma',function(){
    return 'YAHAHAH DIAM LU SUKI';
});



require __DIR__.'/settings.php';
require __DIR__.'/auth.php';
